package com.fiap.locaweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LocawebApplication {

	public static void main(String[] args) {
		SpringApplication.run(LocawebApplication.class, args);
	}

}
